package com.interview.bt.model;

public class Link {

	String link;
	String price;
	
	
	public Link(String link, String price) {
		super();
		this.link = link;
		this.price = price;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	
}
